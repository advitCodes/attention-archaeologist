"""
Challenge generation module for Attention Archaeologist.

Preserves and extends the original Ollama HTTP integration while providing:
- Customizable environment and duration inputs
- Robust response parsing
- Safety and structural validation
- Graceful curated fallbacks when the local LLM is offline or returns unsafe output
"""

import json
import re
import urllib.error
import urllib.request
from typing import Any, Dict, Optional, Tuple

from config import DEFAULT_MODEL, DEFAULT_OLLAMA_URL, OLLAMA_TIMEOUT_SECONDS
from fallbacks import get_fallback_mission
from validator import validate_mission


def build_prompt(environment: str = "Safe outdoor space", duration_minutes: int = 5) -> str:
    """Builds a carefully structured prompt tailored to duration and environment."""
    env_lower = environment.lower()
    if "window" in env_lower:
        env_guidance = (
            "The challenge MUST be performed entirely from inside while looking through a window "
            "at the outdoor scene (sky, buildings, trees, light, reflections)."
        )
    elif "safe outdoor" in env_lower:
        env_guidance = (
            "The challenge MUST be performed from a stationary, safe outdoor spot such as a garden bench, "
            "courtyard, balcony, or park pathway."
        )
    else:
        env_guidance = (
            "The challenge MUST work either from a stationary outdoor space OR from looking out through a window."
        )

    return f"""Generate exactly ONE creative, unusual, engaging {duration_minutes}-minute observation challenge for someone who wants to disconnect from their phone and pay closer attention to the real world.

LOCATION & DURATION:
- Duration: {duration_minutes} minutes.
- {env_guidance}
- The observer must remain in a single stationary spot for the entire duration.

STRICT SAFETY RULES:
- Observation only. Never instruct the user to touch, pick, taste, smell, collect, feed, or disturb anything.
- Never instruct the user to approach wildlife, insects, strangers, roads, water hazards, heights, or hazardous objects.
- Never require gloves, tools, equipment, cameras, or supervision.
- Never suggest entering private property, climbing, or isolated areas.
- Avoid weather-dependent tasks, time-of-day requirements, or rare occurrences.
- Remind the user to remain aware of their surroundings.

CHALLENGE REQUIREMENTS:
- Focus on micro-patterns, light, shadows, textures from afar, wind movements, or acoustic layers.
- Give one specific, intriguing field experiment rather than generic mindfulness advice.
- Include one memory test question that can be answered immediately from memory after the session ends (do NOT ask to predict future events).
- Require zero equipment, cameras, recordings, or apps.
- Achievable by a beginner.

OUTPUT FORMAT (Follow exactly with no intro or markdown preamble):
Mission: [One short, intriguing title]
Observe: [One specific and safe observation task]
Remember: [One question to answer from memory after the session]
Time: {duration_minutes} minutes
"""


def parse_model_response(raw_text: str, duration_minutes: int = 5) -> Optional[Dict[str, str]]:
    """
    Parses key-value pairs (Mission, Observe, Remember, Time) from raw model output.
    Handles optional markdown bolding, prefixes, and varying capitalization.
    """
    if not raw_text or not raw_text.strip():
        return None

    cleaned = raw_text.strip()
    
    # Regex patterns looking for the 4 expected headers
    mission_match = re.search(r"(?:^|\n)\s*(?:\*\*)?Mission(?:\*\*)?\s*:\s*(.+)", cleaned, re.IGNORECASE)
    observe_match = re.search(r"(?:^|\n)\s*(?:\*\*)?Observe(?:\*\*)?\s*:\s*(.+)", cleaned, re.IGNORECASE)
    remember_match = re.search(r"(?:^|\n)\s*(?:\*\*)?Remember(?:\*\*)?\s*:\s*(.+)", cleaned, re.IGNORECASE)
    time_match = re.search(r"(?:^|\n)\s*(?:\*\*)?Time(?:\*\*)?\s*:\s*(.+)", cleaned, re.IGNORECASE)

    if not (mission_match and observe_match and remember_match):
        return None

    # Extract match values, cleaning up trailing lines if multi-line
    def clean_field(m):
        val = m.group(1).strip()
        # Take up to the next recognized header if bundled
        first_line = val.split("\n")[0].strip()
        return first_line if first_line else val

    title = clean_field(mission_match)
    task = clean_field(observe_match)
    question = clean_field(remember_match)
    duration_str = clean_field(time_match) if time_match else f"{duration_minutes} minutes"

    return {
        "title": title,
        "task": task,
        "memory_question": question,
        "duration": duration_str,
    }


def query_ollama(
    prompt: str,
    model: str = DEFAULT_MODEL,
    api_url: str = DEFAULT_OLLAMA_URL,
    timeout: int = OLLAMA_TIMEOUT_SECONDS,
) -> Tuple[bool, str, Optional[str]]:
    """
    Queries the local Ollama instance using the original urllib integration.
    
    Returns:
      (success: bool, status_message: str, response_text: Optional[str])
    """
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
    }

    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        api_url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            if response.status != 200:
                return False, f"Ollama HTTP {response.status}", None
            res_body = response.read().decode("utf-8")
            parsed_json = json.loads(res_body)
            raw_response = parsed_json.get("response", "").strip()
            if not raw_response:
                return False, "Ollama returned an empty response.", None
            return True, "Success", raw_response

    except urllib.error.URLError as e:
        # Common when Ollama is not running or port is closed
        return False, f"Ollama connection unavailable ({e.reason})", None
    except json.JSONDecodeError:
        return False, "Ollama returned an invalid JSON response", None
    except TimeoutError:
        return False, f"Ollama timed out after {timeout}s", None
    except Exception as e:
        return False, f"Ollama query error: {str(e)}", None


def check_ollama_available(
    api_url: str = "http://localhost:11434/api/tags",
    timeout: int = 3,
) -> bool:
    """Quick non-blocking probe to check if Ollama daemon is reachable."""
    req = urllib.request.Request(api_url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.status == 200
    except Exception:
        return False


def generate_mission(
    environment: str = "Safe outdoor space",
    duration_minutes: int = 5,
    model: str = DEFAULT_MODEL,
    api_url: str = DEFAULT_OLLAMA_URL,
) -> Dict[str, Any]:
    """
    Generates a mission, validates it, and seamlessly falls back to a curated
    mission if Ollama is unreachable, times out, or produces invalid output.
    """
    prompt = build_prompt(environment, duration_minutes)
    success, query_msg, raw_response = query_ollama(
        prompt=prompt,
        model=model,
        api_url=api_url,
    )

    if not success:
        fallback = get_fallback_mission(environment, duration_minutes)
        return {
            "mission": fallback,
            "source": "fallback",
            "status_message": f"Local model unavailable ({query_msg}). Loaded curated observation mission.",
            "validation_passed": False,
            "validation_reason": query_msg,
            "raw_response": None,
        }

    # Attempt parsing
    parsed = parse_model_response(raw_response, duration_minutes)
    if not parsed:
        fallback = get_fallback_mission(environment, duration_minutes)
        return {
            "mission": fallback,
            "source": "fallback",
            "status_message": "Model response format malformed. Loaded curated observation mission.",
            "validation_passed": False,
            "validation_reason": "Output did not conform to required Mission/Observe/Remember headers.",
            "raw_response": raw_response,
        }

    # Validate output
    is_valid, validation_reason, cleaned_mission = validate_mission(parsed)
    if not is_valid:
        fallback = get_fallback_mission(environment, duration_minutes)
        return {
            "mission": fallback,
            "source": "fallback",
            "status_message": f"Generated mission rejected by validator ({validation_reason}). Loaded safe curated mission.",
            "validation_passed": False,
            "validation_reason": validation_reason,
            "raw_response": raw_response,
        }

    # Passed validation!
    return {
        "mission": cleaned_mission,
        "source": "ollama",
        "status_message": f"Generated by local model ({model}) and verified.",
        "validation_passed": True,
        "validation_reason": validation_reason,
        "raw_response": raw_response,
    }
