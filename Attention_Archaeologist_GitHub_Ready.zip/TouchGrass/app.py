"""
Attention Archaeologist — Gradio Application

A calm, nature-inspired, editorial web application designed to help people
disconnect from digital screens and pay close attention to the physical world.
"""

import html
from typing import Any, Dict, List, Tuple

import gradio as gr

from config import DEFAULT_DURATION, DEFAULT_ENVIRONMENT, DURATIONS, ENVIRONMENTS
from generator import check_ollama_available, generate_mission
from journal import (
    clear_all_notes,
    delete_field_note,
    load_journal,
    save_field_note,
)

# Custom calm, nature-inspired editorial CSS
CUSTOM_CSS = """
/* Font import for editorial feel */
@import url('https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,600;1,6..72,400&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap');

:root {
    --aa-forest: #223a2c;
    --aa-forest-light: #325340;
    --aa-sage: #5f7464;
    --aa-cream: #faf7f2;
    --aa-card-bg: #ffffff;
    --aa-border: #e4dfd5;
    --aa-border-subtle: #eee9e0;
    --aa-sand: #e8e2d5;
    --aa-earth: #8c6d53;
    --aa-amber: #b07228;
    --aa-text-primary: #1f2722;
    --aa-text-muted: #5e6861;
}

body, .gradio-container {
    background-color: var(--aa-cream) !important;
    font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif !important;
    color: var(--aa-text-primary) !important;
    max-width: 960px !important;
    margin: 0 auto !important;
}

/* App Header & Title Treatment */
.app-header {
    text-align: center;
    padding: 2.2rem 1rem 1.4rem 1rem;
    margin-bottom: 0.8rem;
    border-bottom: 1px solid var(--aa-border);
}

.app-title {
    font-family: 'Newsreader', Georgia, serif;
    font-size: 2.5rem;
    font-weight: 600;
    color: var(--aa-forest);
    letter-spacing: -0.02em;
    margin: 0;
    line-height: 1.15;
}

.app-subtitle {
    font-family: 'Newsreader', Georgia, serif;
    font-style: italic;
    font-size: 1.15rem;
    color: var(--aa-sage);
    margin-top: 0.45rem;
    margin-bottom: 0.2rem;
}

.status-badge-container {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.35rem 0.85rem;
    background: #edf2ee;
    border: 1px solid #d4ded6;
    border-radius: 999px;
    font-size: 0.82rem;
    color: var(--aa-forest);
    margin-top: 0.6rem;
}

/* Editorial Card Styles */
.editorial-card {
    background: var(--aa-card-bg);
    border: 1px solid var(--aa-border);
    border-radius: 14px;
    padding: 1.8rem 2rem;
    margin: 1rem 0;
    box-shadow: 0 4px 18px rgba(34, 58, 44, 0.04);
}

.card-tag {
    display: inline-block;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 600;
    color: var(--aa-sage);
    background: #f1ede4;
    padding: 0.2rem 0.6rem;
    border-radius: 4px;
    margin-bottom: 0.75rem;
}

.mission-headline {
    font-family: 'Newsreader', Georgia, serif;
    font-size: 1.85rem;
    font-weight: 600;
    color: var(--aa-forest);
    line-height: 1.25;
    margin: 0.2rem 0 1rem 0;
}

.mission-task-body {
    font-size: 1.05rem;
    line-height: 1.6;
    color: #2b362f;
    margin-bottom: 1.2rem;
    padding-left: 1rem;
    border-left: 3px solid var(--aa-sage);
}

.mission-lock-notice {
    font-size: 0.88rem;
    color: var(--aa-earth);
    background: #f9f5f0;
    border: 1px dashed #ded4c3;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-top: 1rem;
}

/* Timer Display */
.timer-hero-box {
    text-align: center;
    padding: 2.2rem 1.5rem;
    background: #fdfbf7;
    border: 1px solid var(--aa-border);
    border-radius: 16px;
    margin: 1.2rem 0;
}

.timer-digits {
    font-family: 'Newsreader', Georgia, monospace, serif;
    font-size: 4.5rem;
    font-weight: 600;
    color: var(--aa-forest);
    letter-spacing: 0.02em;
    line-height: 1;
    margin: 0.5rem 0;
}

.timer-subtext {
    font-size: 1rem;
    color: var(--aa-sage);
    max-width: 480px;
    margin: 0 auto;
}

/* Journal Entry Cards */
.journal-entry-card {
    background: var(--aa-card-bg);
    border: 1px solid var(--aa-border);
    border-radius: 12px;
    padding: 1.4rem 1.6rem;
    margin-bottom: 1.2rem;
    box-shadow: 0 2px 10px rgba(0,0,0,0.03);
}

.journal-header {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    flex-wrap: wrap;
    gap: 0.5rem;
    border-bottom: 1px solid var(--aa-border-subtle);
    padding-bottom: 0.6rem;
    margin-bottom: 0.8rem;
}

.journal-date {
    font-size: 0.82rem;
    color: var(--aa-text-muted);
}

.journal-meta-badge {
    font-size: 0.75rem;
    background: #edf2ee;
    color: var(--aa-forest);
    padding: 0.15rem 0.5rem;
    border-radius: 6px;
    font-weight: 500;
}

.journal-title {
    font-family: 'Newsreader', Georgia, serif;
    font-size: 1.45rem;
    font-weight: 600;
    color: var(--aa-forest);
    margin: 0.2rem 0 0.8rem 0;
}

.journal-section-label {
    font-size: 0.76rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--aa-sage);
    margin-top: 0.8rem;
    margin-bottom: 0.2rem;
}

.journal-recall-content {
    font-size: 0.96rem;
    line-height: 1.55;
    color: var(--aa-text-primary);
    background: #faf8f5;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    border-left: 3px solid var(--aa-forest);
}

.journal-reflection-content {
    font-size: 0.92rem;
    line-height: 1.5;
    font-style: italic;
    color: #4a544c;
    background: #fbf9f5;
    border-radius: 8px;
    padding: 0.6rem 0.9rem;
    margin-top: 0.4rem;
}

.journal-original-box {
    margin-top: 0.9rem;
    padding: 0.8rem 1rem;
    background: #f4efe6;
    border-radius: 8px;
    font-size: 0.88rem;
    border: 1px solid #e2dac9;
}

/* Custom button tweaks */
button.primary-forest {
    background-color: var(--aa-forest) !important;
    color: #ffffff !important;
    border-radius: 8px !important;
    font-weight: 500 !important;
}

button.primary-forest:hover {
    background-color: var(--aa-forest-light) !important;
}
"""


def format_seconds_to_mmss(total_seconds: int) -> str:
    """Formats an integer number of seconds into MM:SS format."""
    total_seconds = max(0, int(total_seconds))
    mins = total_seconds // 60
    secs = total_seconds % 60
    return f"{mins:02d}:{secs:02d}"


def get_system_status_indicator() -> str:
    """Returns an HTML badge indicating local model readiness."""
    is_online = check_ollama_available()
    if is_online:
        return """
        <div class="status-badge-container">
            <span style="color: #2e7d32;">●</span>
            <span>Local Model Engine: <strong>smollm2:1.7b</strong> connected</span>
        </div>
        """
    else:
        return """
        <div class="status-badge-container" style="background: #faf4eb; border-color: #eedcc6;">
            <span style="color: #b07228;">●</span>
            <span>Curated Offline Engine Active (Ollama offline on :11434)</span>
        </div>
        """


def render_briefing_html(mission: Dict[str, Any], status_msg: str = "") -> str:
    """Renders the generated mission briefing card in editorial style."""
    if not mission:
        return ""
    
    title = html.escape(mission.get("title", "Untitled Observation"))
    task = html.escape(mission.get("task", ""))
    duration = html.escape(str(mission.get("duration", "5 minutes")))
    status_html = f"<div style='font-size:0.8rem; color:#5e6861; margin-top:0.8rem;'>ℹ️ {html.escape(status_msg)}</div>" if status_msg else ""

    return f"""
    <div class="editorial-card">
        <div class="card-tag">Observation Mission • {duration}</div>
        <h2 class="mission-headline">{title}</h2>
        <div class="mission-task-body">{task}</div>
        <div class="mission-lock-notice">
            <span>🔒</span>
            <span><strong>Memory Challenge Locked:</strong> Put your phone away and step outside or to your window. When you return, you will reconstruct what you observed from memory.</span>
        </div>
        {status_html}
    </div>
    """


def render_timer_html(seconds_left: int, is_paused: bool = False) -> str:
    """Renders the countdown timer display."""
    time_str = format_seconds_to_mmss(seconds_left)
    state_label = "Countdown Paused" if is_paused else "Stationary Observation in Progress"
    status_color = "#b07228" if is_paused else "#5f7464"
    
    if seconds_left <= 0:
        return f"""
        <div class="timer-hero-box" style="border-color: #2e7d32; background: #f2f7f3;">
            <div style="font-size: 0.85rem; font-weight: 600; text-transform: uppercase; color: #2e7d32; letter-spacing: 0.08em;">
                Session Complete
            </div>
            <div class="timer-digits" style="color: #2e7d32;">00:00</div>
            <p class="timer-subtext" style="color: #2e7d32; font-weight: 500;">
                Welcome back. When you're ready, proceed to Blind Recall to reconstruct your observations before seeing the prompts again.
            </p>
        </div>
        """

    return f"""
    <div class="timer-hero-box">
        <div style="font-size: 0.85rem; font-weight: 600; text-transform: uppercase; color: {status_color}; letter-spacing: 0.08em;">
            {state_label}
        </div>
        <div class="timer-digits">{time_str}</div>
        <p class="timer-subtext">
            Place your phone face down or in your pocket. Stay stationary and observe your surroundings without documenting or recording.
        </p>
    </div>
    """


def render_reveal_html(
    mission: Dict[str, Any],
    recall_text: str,
    reflection_text: str = "",
) -> str:
    """Renders the side-by-side comparative unearth & reveal screen."""
    if not mission:
        return ""

    title = html.escape(mission.get("title", ""))
    task = html.escape(mission.get("task", ""))
    memory_question = html.escape(mission.get("memory_question", ""))
    duration = html.escape(str(mission.get("duration", "")))
    recall_clean = html.escape(recall_text.strip())
    refl_clean = html.escape(reflection_text.strip())

    reflection_html = ""
    if refl_clean:
        reflection_html = f"""
        <div class="journal-section-label" style="margin-top:1rem;">Your Reflection</div>
        <div class="journal-reflection-content">"{refl_clean}"</div>
        """

    return f"""
    <div class="editorial-card">
        <div class="card-tag">Phase 3 • Unearth & Compare</div>
        <h2 class="mission-headline">Observation Debrief</h2>
        <p style="font-size: 0.95rem; color: #5e6861; margin-top:-0.5rem; margin-bottom: 1.4rem;">
            Here is your unedited blind recall placed alongside the target challenge and locked memory test.
        </p>

        <div style="display: grid; grid-template-columns: 1fr; gap: 1.2rem;">
            <!-- Recall Card -->
            <div style="background: #ffffff; border: 1px solid #dcd7cb; border-radius: 10px; padding: 1.2rem;">
                <div class="journal-section-label" style="color:#223a2c;">Your Blind Field Recall</div>
                <div class="journal-recall-content" style="margin-top: 0.4rem;">
                    {recall_clean if recall_clean else '<em>(No recall notes recorded)</em>'}
                </div>
                {reflection_html}
            </div>

            <!-- Original Mission Card -->
            <div style="background: #fbf9f4; border: 1px solid #e2dacb; border-radius: 10px; padding: 1.2rem;">
                <div class="card-tag" style="background:#e8dfd0;">Original Briefing • {duration}</div>
                <h3 style="font-family:'Newsreader', Georgia, serif; font-size:1.3rem; margin:0.3rem 0; color:#223a2c;">{title}</h3>
                <div style="font-size:0.92rem; color:#3b463e; line-height:1.5; margin-bottom: 0.9rem;">
                    <strong>Original Task:</strong> {task}
                </div>
                
                <div style="background: #f1ede1; border-left: 3px solid #b07228; border-radius: 6px; padding: 0.75rem 1rem;">
                    <div style="font-size: 0.78rem; text-transform: uppercase; font-weight: 600; color: #8c5b20; letter-spacing: 0.05em;">
                        Target Memory Question (Now Revealed)
                    </div>
                    <div style="font-size: 1.02rem; font-family:'Newsreader', Georgia, serif; font-weight:600; color: #223a2c; margin-top: 0.3rem;">
                        "{memory_question}"
                    </div>
                </div>
            </div>
        </div>
    </div>
    """


def render_journal_view() -> Tuple[str, gr.Dropdown]:
    """Renders the HTML entries for the Field Journal and builds dropdown choices for deletion."""
    entries = load_journal()
    if not entries:
        html_content = """
        <div class="editorial-card" style="text-align: center; padding: 3rem 1.5rem;">
            <div style="font-size: 2.2rem; margin-bottom: 0.5rem;">🌱</div>
            <h3 style="font-family:'Newsreader', Georgia, serif; font-size: 1.4rem; color: #223a2c; margin: 0.2rem 0;">
                Your Field Journal is Empty
            </h3>
            <p style="color: #6d7870; max-width: 420px; margin: 0.5rem auto 0 auto; font-size: 0.95rem;">
                No observation notes have been archived yet. Complete a mission and submit your Blind Recall to preserve your first field discovery.
            </p>
        </div>
        """
        return html_content, gr.Dropdown(choices=[], value=None)

    html_cards = []
    dropdown_choices = []

    for idx, e in enumerate(entries):
        entry_id = e.get("id", str(idx))
        timestamp = html.escape(e.get("timestamp", "Undated"))
        title = html.escape(e.get("mission_title", "Untitled Observation"))
        env = html.escape(e.get("environment", "Outdoor"))
        duration = html.escape(str(e.get("duration", "5 minutes")))
        recall = html.escape(e.get("recall", ""))
        reflection = html.escape(e.get("reflection", ""))
        orig = e.get("original_mission", {})
        orig_task = html.escape(orig.get("task", ""))
        orig_q = html.escape(orig.get("memory_question", ""))

        choice_label = f"{timestamp} — {title}"
        dropdown_choices.append((choice_label, entry_id))

        reflection_markup = ""
        if reflection:
            reflection_markup = f"""
            <div class="journal-section-label">Reflection</div>
            <div class="journal-reflection-content">"{reflection}"</div>
            """

        card_html = f"""
        <div class="journal-entry-card">
            <div class="journal-header">
                <div>
                    <h3 class="journal-title">{title}</h3>
                    <span class="journal-date">{timestamp}</span>
                </div>
                <div class="journal-meta-badge">{duration} • {env}</div>
            </div>
            
            <div class="journal-section-label">Field Recall</div>
            <div class="journal-recall-content">{recall}</div>
            {reflection_markup}

            <details class="journal-original-box" style="cursor: pointer; margin-top: 0.8rem;">
                <summary style="font-weight: 500; color: #5f7464;">View original mission briefing & memory test</summary>
                <div style="margin-top: 0.6rem; padding-top: 0.6rem; border-top: 1px dashed #dcd4c3;">
                    <p style="margin: 0.2rem 0;"><strong>Task:</strong> {orig_task}</p>
                    <p style="margin: 0.3rem 0; color: #8c5b20;"><strong>Memory Question:</strong> {orig_q}</p>
                </div>
            </details>
        </div>
        """
        html_cards.append(card_html)

    combined_html = "\n".join(html_cards)
    return combined_html, gr.Dropdown(choices=dropdown_choices, value=None)


APP_THEME = gr.themes.Soft(
    primary_hue="emerald",
    neutral_hue="stone",
    font=[gr.themes.GoogleFont("Plus Jakarta Sans"), "system-ui", "sans-serif"],
)


def build_app() -> gr.Blocks:
    """Builds and wires up the full Attention Archaeologist Gradio application."""
    with gr.Blocks(title="Attention Archaeologist") as demo:
        # App-level state variables
        current_mission_state = gr.State({})
        timer_seconds_state = gr.State(300)
        timer_is_paused_state = gr.State(False)
        selected_env_state = gr.State(DEFAULT_ENVIRONMENT)
        selected_duration_state = gr.State(DEFAULT_DURATION)
        last_recall_text_state = gr.State("")
        last_reflection_text_state = gr.State("")

        # Application Header
        gr.HTML("""
        <div class="app-header">
            <div style="font-size: 1.6rem; margin-bottom: 0.2rem;">🧭 🌿</div>
            <h1 class="app-title">Attention Archaeologist</h1>
            <p class="app-subtitle">Disconnect from the digital haze. Unearth the details hidden in plain sight.</p>
        </div>
        """)

        # System Status Bar
        status_bar_html = gr.HTML(value=get_system_status_indicator())

        # Main Navigation Tabs
        with gr.Tabs() as tabs:
            # TAB 1: Mission Flow
            with gr.TabItem("🧭 Observation Mission", id="tab_mission"):
                
                # ----------------- SCREEN 1: SETUP -----------------
                with gr.Group(visible=True) as view_setup:
                    gr.Markdown("### 1. Mission Briefing Parameters")
                    gr.Markdown(
                        "Select where you are and how much time you have to step away from your screen. "
                        "We will formulate a single, stationary observation challenge."
                    )
                    
                    with gr.Row():
                        input_env = gr.Radio(
                            choices=ENVIRONMENTS,
                            value=DEFAULT_ENVIRONMENT,
                            label="Observation Environment",
                            info="All missions are safe, beginner-friendly, and stationary.",
                        )
                        input_duration = gr.Radio(
                            choices=DURATIONS,
                            value=DEFAULT_DURATION,
                            label="Duration (Minutes)",
                            info="Short, high-focus time window to step away.",
                        )

                    btn_generate = gr.Button(
                        "Generate Observation Mission",
                        variant="primary",
                        size="lg",
                    )
                    gen_status_msg = gr.Markdown(value="", visible=False)

                # ----------------- SCREEN 2: GENERATED MISSION -----------------
                with gr.Group(visible=False) as view_briefing:
                    briefing_display_html = gr.HTML(value="")
                    
                    with gr.Row():
                        btn_start_mission = gr.Button(
                            "Begin Mission (Put Phone Away)",
                            variant="primary",
                            size="lg",
                        )
                        btn_regenerate = gr.Button(
                            "Try Another Mission",
                            variant="secondary",
                            size="lg",
                        )

                # ----------------- SCREEN 3: ACTIVE OBSERVATION SESSION -----------------
                with gr.Group(visible=False) as view_session:
                    session_timer_html = gr.HTML(value="")
                    
                    # Gradio periodic timer ticking every 1 second
                    session_timer = gr.Timer(value=1.0, active=False)

                    with gr.Row():
                        btn_pause_resume = gr.Button(
                            "Pause Timer",
                            variant="secondary",
                        )
                        btn_im_back = gr.Button(
                            "I'm Back: Proceed to Blind Recall",
                            variant="primary",
                            size="lg",
                        )

                # ----------------- SCREEN 4: BLIND RECALL -----------------
                with gr.Group(visible=False) as view_recall:
                    gr.Markdown("### 2. Blind Recall")
                    gr.Markdown(
                        "> [!IMPORTANT]\n"
                        "> **Do not look back at the original briefing yet.** Reconstruct what you noticed strictly from memory. "
                        "The original challenge and memory test will only be revealed after you submit."
                    )

                    recall_input = gr.Textbox(
                        label="What did you observe?",
                        placeholder="Describe the textures, light, shadows, sounds, patterns, or movements you experienced while in your spot...",
                        lines=5,
                    )
                    reflection_input = gr.Textbox(
                        label="Reflection (Optional)",
                        placeholder="What surprised you? What did you almost overlook before slowing down?",
                        lines=3,
                    )

                    btn_submit_recall = gr.Button(
                        "Submit Field Recall & Unearth Mission",
                        variant="primary",
                        size="lg",
                    )

                # ----------------- SCREEN 5: REVEAL & SAVE -----------------
                with gr.Group(visible=False) as view_reveal:
                    reveal_display_html = gr.HTML(value="")
                    save_feedback_msg = gr.Markdown(value="", visible=False)

                    with gr.Row():
                        btn_save_note = gr.Button(
                            "💾 Save Note to Field Journal",
                            variant="primary",
                            size="lg",
                        )
                        btn_new_mission = gr.Button(
                            "🌱 Begin Another Mission",
                            variant="secondary",
                            size="lg",
                        )

            # TAB 2: Field Journal
            with gr.TabItem("📖 Field Journal", id="tab_journal"):
                gr.Markdown("### Personal Observation Journal")
                gr.Markdown(
                    "Your archived field notes are stored locally on your device in `field_journal.json`. "
                    "No data is ever transmitted to external servers."
                )

                btn_refresh_journal = gr.Button("🔄 Refresh Journal", variant="secondary", size="sm")
                journal_entries_display = gr.HTML(value="")

                with gr.Accordion("⚙️ Journal Management (Delete or Clear)", open=False):
                    gr.Markdown("#### Delete Individual Note")
                    delete_dropdown = gr.Dropdown(
                        label="Select Note to Remove",
                        choices=[],
                        value=None,
                    )
                    delete_confirm_check = gr.Checkbox(
                        label="I confirm I want to permanently delete this field note.",
                        value=False,
                    )
                    btn_delete_note = gr.Button("Delete Selected Note", variant="stop", size="sm")

                    gr.Markdown("---")
                    gr.Markdown("#### Clear Entire Journal")
                    clear_confirm_check = gr.Checkbox(
                        label="I understand this will permanently delete ALL archived field notes.",
                        value=False,
                    )
                    btn_clear_journal = gr.Button("Clear Entire Journal", variant="stop", size="sm")
                    
                    journal_action_status = gr.Markdown(value="", visible=False)

        # ==========================================
        # EVENT HANDLERS & STATE TRANSITIONS
        # ==========================================

        # 1. Generate Mission
        def handle_generate(env: str, duration_mins: int):
            result = generate_mission(environment=env, duration_minutes=int(duration_mins))
            mission = result["mission"]
            status_text = result["status_message"]
            briefing_markup = render_briefing_html(mission, status_text)
            seconds = int(duration_mins) * 60

            return (
                mission,                               # current_mission_state
                seconds,                               # timer_seconds_state
                False,                                 # timer_is_paused_state
                env,                                   # selected_env_state
                int(duration_mins),                    # selected_duration_state
                gr.Group(visible=False),               # view_setup
                gr.Group(visible=True),                # view_briefing
                briefing_markup,                       # briefing_display_html
            )

        btn_generate.click(
            fn=handle_generate,
            inputs=[input_env, input_duration],
            outputs=[
                current_mission_state,
                timer_seconds_state,
                timer_is_paused_state,
                selected_env_state,
                selected_duration_state,
                view_setup,
                view_briefing,
                briefing_display_html,
            ],
        )

        # 2. Regenerate / Try Another
        def handle_regenerate():
            return (
                gr.Group(visible=True),   # view_setup
                gr.Group(visible=False),  # view_briefing
                gr.Group(visible=False),  # view_session
                gr.Group(visible=False),  # view_recall
                gr.Group(visible=False),  # view_reveal
            )

        btn_regenerate.click(
            fn=handle_regenerate,
            outputs=[view_setup, view_briefing, view_session, view_recall, view_reveal],
        )

        # 3. Begin Mission -> Transition to Observation Session & Activate Timer
        def handle_start_mission(seconds: int):
            timer_markup = render_timer_html(seconds, is_paused=False)
            return (
                gr.Group(visible=False),          # view_briefing
                gr.Group(visible=True),           # view_session
                timer_markup,                     # session_timer_html
                gr.Timer(active=True),            # session_timer
                False,                            # timer_is_paused_state
                "Pause Timer",                    # btn_pause_resume text
            )

        btn_start_mission.click(
            fn=handle_start_mission,
            inputs=[timer_seconds_state],
            outputs=[
                view_briefing,
                view_session,
                session_timer_html,
                session_timer,
                timer_is_paused_state,
                btn_pause_resume,
            ],
        )

        # 4. Timer Tick (runs every 1 second when active)
        def handle_timer_tick(current_secs: int, is_paused: bool):
            if is_paused or current_secs <= 0:
                return current_secs, render_timer_html(current_secs, is_paused=is_paused), gr.Timer(active=current_secs > 0 and not is_paused)
            
            new_secs = max(0, current_secs - 1)
            markup = render_timer_html(new_secs, is_paused=False)
            timer_active = gr.Timer(active=True) if new_secs > 0 else gr.Timer(active=False)
            return new_secs, markup, timer_active

        session_timer.tick(
            fn=handle_timer_tick,
            inputs=[timer_seconds_state, timer_is_paused_state],
            outputs=[timer_seconds_state, session_timer_html, session_timer],
        )

        # 5. Pause / Resume Timer
        def handle_toggle_pause(current_secs: int, is_paused: bool):
            new_paused_state = not is_paused
            markup = render_timer_html(current_secs, is_paused=new_paused_state)
            btn_label = "Resume Timer" if new_paused_state else "Pause Timer"
            timer_active = gr.Timer(active=not new_paused_state and current_secs > 0)
            return new_paused_state, markup, btn_label, timer_active

        btn_pause_resume.click(
            fn=handle_toggle_pause,
            inputs=[timer_seconds_state, timer_is_paused_state],
            outputs=[timer_is_paused_state, session_timer_html, btn_pause_resume, session_timer],
        )

        # 6. Proceed to Blind Recall ("I'm Back")
        def handle_proceed_to_recall():
            return (
                gr.Timer(active=False),           # stop timer
                gr.Group(visible=False),          # view_session
                gr.Group(visible=True),           # view_recall
                "",                               # clear recall_input
                "",                               # clear reflection_input
            )

        btn_im_back.click(
            fn=handle_proceed_to_recall,
            outputs=[
                session_timer,
                view_session,
                view_recall,
                recall_input,
                reflection_input,
            ],
        )

        # 7. Submit Blind Recall -> Reveal Original Mission & Target Question
        def handle_submit_recall(mission: Dict[str, Any], recall: str, refl: str):
            clean_recall = recall.strip() if recall else "No recall notes entered."
            clean_refl = refl.strip() if refl else ""
            reveal_markup = render_reveal_html(mission, clean_recall, clean_refl)

            return (
                clean_recall,                     # last_recall_text_state
                clean_refl,                       # last_reflection_text_state
                gr.Group(visible=False),          # view_recall
                gr.Group(visible=True),           # view_reveal
                reveal_markup,                    # reveal_display_html
                gr.Markdown(visible=False),       # save_feedback_msg
                gr.Button(interactive=True, value="💾 Save Note to Field Journal"), # reset save btn
            )

        btn_submit_recall.click(
            fn=handle_submit_recall,
            inputs=[current_mission_state, recall_input, reflection_input],
            outputs=[
                last_recall_text_state,
                last_reflection_text_state,
                view_recall,
                view_reveal,
                reveal_display_html,
                save_feedback_msg,
                btn_save_note,
            ],
        )

        # 8. Save Note to Local Journal
        def handle_save_note(mission: Dict[str, Any], recall: str, refl: str, env: str, duration: int):
            entry = save_field_note(
                mission=mission,
                recall_text=recall,
                reflection_text=refl,
                environment=env,
                duration_minutes=duration,
            )
            if entry:
                msg = "> [!NOTE]\n> **Field note saved successfully!** You can view it anytime in the Field Journal tab."
                return gr.Markdown(value=msg, visible=True), gr.Button(interactive=False, value="✓ Note Saved")
            else:
                msg = "> [!WARNING]\n> **Failed to write field note.** Please check file permissions for `field_journal.json`."
                return gr.Markdown(value=msg, visible=True), gr.Button(interactive=True, value="💾 Save Note to Field Journal")

        btn_save_note.click(
            fn=handle_save_note,
            inputs=[
                current_mission_state,
                last_recall_text_state,
                last_reflection_text_state,
                selected_env_state,
                selected_duration_state,
            ],
            outputs=[save_feedback_msg, btn_save_note],
        )

        # 9. Begin Another Mission
        def handle_new_mission_reset():
            return (
                gr.Group(visible=True),           # view_setup
                gr.Group(visible=False),          # view_briefing
                gr.Group(visible=False),          # view_session
                gr.Group(visible=False),          # view_recall
                gr.Group(visible=False),          # view_reveal
                {},                               # clear mission
            )

        btn_new_mission.click(
            fn=handle_new_mission_reset,
            outputs=[
                view_setup,
                view_briefing,
                view_session,
                view_recall,
                view_reveal,
                current_mission_state,
            ],
        )

        # 10. Refresh Field Journal Tab
        def handle_refresh_journal():
            markup, dropdown_update = render_journal_view()
            return markup, dropdown_update, gr.Markdown(visible=False)

        btn_refresh_journal.click(
            fn=handle_refresh_journal,
            outputs=[journal_entries_display, delete_dropdown, journal_action_status],
        )

        # Trigger initial journal load when page loads
        demo.load(
            fn=handle_refresh_journal,
            outputs=[journal_entries_display, delete_dropdown, journal_action_status],
        )

        # 11. Delete Single Note
        def handle_delete_single_note(note_id: str, is_confirmed: bool):
            if not note_id:
                return (
                    gr.Markdown(value="⚠️ Please select a note from the dropdown first.", visible=True),
                    *render_journal_view(),
                    False,
                )
            if not is_confirmed:
                return (
                    gr.Markdown(value="⚠️ Please check the confirmation box before deleting.", visible=True),
                    *render_journal_view(),
                    False,
                )
            
            success = delete_field_note(note_id)
            if success:
                msg = "✓ Note deleted from journal."
            else:
                msg = "⚠️ Could not find or delete note."

            markup, dd = render_journal_view()
            return gr.Markdown(value=msg, visible=True), markup, dd, False

        btn_delete_note.click(
            fn=handle_delete_single_note,
            inputs=[delete_dropdown, delete_confirm_check],
            outputs=[
                journal_action_status,
                journal_entries_display,
                delete_dropdown,
                delete_confirm_check,
            ],
        )

        # 12. Clear All Notes
        def handle_clear_all_notes(is_confirmed: bool):
            if not is_confirmed:
                return (
                    gr.Markdown(value="⚠️ Please check the confirmation box to confirm clearing all notes.", visible=True),
                    *render_journal_view(),
                    False,
                )
            clear_all_notes()
            markup, dd = render_journal_view()
            return gr.Markdown(value="✓ All field notes have been cleared.", visible=True), markup, dd, False

        btn_clear_journal.click(
            fn=handle_clear_all_notes,
            inputs=[clear_confirm_check],
            outputs=[
                journal_action_status,
                journal_entries_display,
                delete_dropdown,
                clear_confirm_check,
            ],
        )

    return demo


if __name__ == "__main__":
    app = build_app()
    app.launch(
        server_name="127.0.0.1",
        server_port=7860,
        show_error=True,
        theme=APP_THEME,
        css=CUSTOM_CSS,
    )
