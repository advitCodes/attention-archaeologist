# 🧭 Attention Archaeologist

> *Disconnect from the digital haze. Unearth the details hidden in plain sight.*

**Attention Archaeologist** is a calm, local-first web application designed to help people disconnect from their phones and pay closer attention to the physical world.

Rather than being a generic meditation app or chatbot wrapper, it operates on a focused, novel loop:

1. **Mission Briefing:** Generates a creative, stationary observation challenge (from a window or safe outdoor spot).
2. **Put Phone Away:** The user locks their phone or places it face down and observes their surroundings for 3, 5, or 7 minutes.
3. **Blind Recall:** Upon returning, the user reconstructs what they noticed *without* seeing the original instructions or hints again.
4. **Unearth & Reveal:** The locked target memory question is revealed side-by-side with the user's recall.
5. **Field Journal:** Observations and reflections are archived locally on disk in `field_journal.json`.

---

## 🏗️ Architecture

```
TouchGrass/
├── app.py              # Gradio web UI, visual countdown, state machine & editorial theme
├── config.py           # Configuration constants, Ollama endpoint, defaults, and paths
├── generator.py        # Ollama API client (urllib), prompt engineering & parser
├── validator.py        # Structural & heuristic safety validator for observation challenges
├── fallbacks.py        # Curated catalog of safe, stationary micro-experiment missions
├── journal.py          # Atomic JSON local storage for user field notes
├── main.py             # Main entry point (launches web app or runs CLI tests)
├── touch-grass.py      # Convenience alias launcher for main.py
├── test_app.py         # Unit tests (validator, parser, journal resilience, fallbacks)
├── test_e2e_flow.py    # End-to-end user lifecycle test
├── requirements.txt    # Project dependencies (gradio)
├── field_journal.json  # Local user journal storage (created on first note save; git-ignored)
└── README.md           # Documentation, setup guide, and architectural reference
```

---

## 🚀 Quick Start Guide

### Prerequisites

- **Python 3.10+** (Tested and verified on Python 3.14)
- **Ollama** (optional but recommended for AI mission generation)
  - Pre-configured model: `smollm2:1.7b`

### 1. Setup Environment

Clone or navigate into the repository:

```bash
cd TouchGrass
```

Create and activate a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

### 2. (Optional) Run the Local Model with Ollama

If you wish to use the local neural model, ensure Ollama is running and has `smollm2:1.7b` downloaded:

```bash
# In a separate terminal or background:
ollama run smollm2:1.7b
```

> **Note:** If Ollama is offline or `smollm2:1.7b` is not installed, **the app still works completely**! It automatically falls back to an offline curated catalog of safe, stationary observation missions.

### 3. Launch the Application

Start the web interface:

```bash
python main.py
```

Or run via the virtual environment directly:

```bash
.venv/bin/python main.py
```

Open your browser at:
👉 **`http://127.0.0.1:7860`**

### 4. Command-Line Options

- Run a headless test generator in your terminal without opening the browser:
  ```bash
  python main.py --cli
  ```
- Change port or host:
  ```bash
  python main.py --port 8080 --host 0.0.0.0
  ```
- Create a temporary Gradio shareable link:
  ```bash
  python main.py --share
  ```

---

## 🔒 Safety & Validation Framework

The application treats all AI outputs with zero trust using `validator.py`:

1. **Observation-Only Rule:** Rejects missions instructing physical contact (touching, petting, tasting, smelling, picking, gathering, breaking, pulling, or feeding).
2. **Hazard Mitigation:** Strictly rejects instructions approaching strangers, climbing heights (roofs, ledges, fences, ladders), crossing roads/traffic, or entering private property.
3. **No Equipment Requirements:** Rejects instructions requiring cameras, phone apps, microphones, or measuring tools during observation.
4. **No Predictive / Future Questions:** Memory questions must test what the user observed during the session, not predict future events (e.g. rejecting "What will happen tomorrow?").
5. **Curated Fallbacks:** If the model returns malformed text, is offline, or generates an unsafe prompt, the app seamlessly substitutes a hand-crafted, safe observation experiment from `fallbacks.py`.

> *Disclaimer:* The validator provides heuristic and structural sanity checks, but cannot guarantee absolute real-world safety under every physical condition. Users should always exercise personal judgment and maintain awareness of their surroundings.

---

## 📓 Privacy & Data Ownership

- **100% Local-First:** All field notes, reflections, and observation logs are stored directly on your computer in `field_journal.json`.
- **Zero External Telemetry:** No user tracking, no third-party APIs, and no telemetry.
- **Local Model:** When using Ollama, prompt completions are run entirely on your local GPU/CPU.
- **Journal Management:** Easily review, delete individual notes, or clear your entire journal directly from the "Field Journal" tab with confirmation guards.

---

## 🧪 Running Automated Tests

Run the full automated test suite anytime:

```bash
# Run unit tests
.venv/bin/python test_app.py

# Run end-to-end user lifecycle test
.venv/bin/python test_e2e_flow.py
```

---

## 🛠️ Troubleshooting

| Issue | Cause | Solution |
| :--- | :--- | :--- |
| **Yellow status badge: "Curated Offline Engine Active"** | Ollama daemon is not running on `localhost:11434` or model is downloading. | Start Ollama with `ollama serve` or run `ollama run smollm2:1.7b`. The app continues to work with curated fallbacks. |
| **Port 7860 in use** | Another Gradio instance is already running. | Specify another port: `python main.py --port 7861`. |
| **ModuleNotFoundError: No module named 'gradio'** | Running with system Python instead of the virtual environment. | Activate the venv with `source .venv/bin/activate` or invoke via `.venv/bin/python main.py`. |

---

## 📝 Known Limitations

- `smollm2:1.7b` is a lightweight 1.7B parameter model; occasionally its output syntax may vary. The built-in regex parser and heuristic validator catch non-conformances and smoothly swap in curated fallbacks.
- Web browser audio chimes for the timer depend on browser autoplay permissions when returning to the tab.
