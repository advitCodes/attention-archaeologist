"""Configuration constants and paths for Attention Archaeologist."""
import os
from pathlib import Path

# Project root directory
BASE_DIR = Path(__file__).resolve().parent

# Ollama local settings
DEFAULT_OLLAMA_URL = os.environ.get("OLLAMA_API_URL", "http://localhost:11434/api/generate")
DEFAULT_MODEL = os.environ.get("OLLAMA_MODEL", "smollm2:1.7b")
OLLAMA_TIMEOUT_SECONDS = int(os.environ.get("OLLAMA_TIMEOUT", "45"))

# Storage paths
JOURNAL_FILE_PATH = BASE_DIR / "field_journal.json"

# Observation parameters
ENVIRONMENTS = [
    "Safe outdoor space",
    "Through a window",
    "Either"
]

DURATIONS = [3, 5, 7]  # In minutes
DEFAULT_DURATION = 5
DEFAULT_ENVIRONMENT = "Safe outdoor space"
