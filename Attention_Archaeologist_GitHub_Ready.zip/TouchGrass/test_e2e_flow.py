"""
End-to-end functional flow test for Attention Archaeologist.
Tests the entire user lifecycle:
1. Generation -> Briefing
2. Mission Start -> Timer
3. Timer Tick & Pause/Resume
4. Transition to Blind Recall (ensuring mission is hidden)
5. Submit Recall -> Reveal Original Mission
6. Save Note to Local Journal
7. View & Delete Note in Journal
"""

import tempfile
from pathlib import Path
import config
import journal
from app import (
    build_app,
    format_seconds_to_mmss,
    render_briefing_html,
    render_reveal_html,
    render_journal_view,
    render_timer_html,
)
from generator import generate_mission


def test_full_lifecycle():
    print("Beginning End-to-End lifecycle test...")

    # Use temporary journal file for test
    with tempfile.TemporaryDirectory() as tmp_dir:
        test_journal = Path(tmp_dir) / "field_journal_test.json"
        config.JOURNAL_FILE_PATH = test_journal

        # 1. Generate Mission
        print("1. Testing Mission Generation...")
        result = generate_mission(environment="Safe outdoor space", duration_minutes=5)
        mission = result["mission"]
        assert mission is not None
        assert "title" in mission
        assert "task" in mission
        assert "memory_question" in mission
        print(f"   -> Mission created: '{mission['title']}' ({result['source']})")

        # 2. Briefing View
        print("2. Testing Briefing Markup...")
        briefing_html = render_briefing_html(mission, result["status_message"])
        assert mission["title"] in briefing_html
        assert mission["task"] in briefing_html
        assert "Memory Challenge Locked" in briefing_html
        # Verify the memory question is NOT in the briefing!
        assert mission["memory_question"] not in briefing_html
        print("   -> Briefing rendered with locked memory question.")

        # 3. Timer Formatting & Countdown
        print("3. Testing Timer Display...")
        timer_5m = render_timer_html(300, is_paused=False)
        assert "05:00" in timer_5m
        assert "Stationary Observation in Progress" in timer_5m

        timer_paused = render_timer_html(240, is_paused=True)
        assert "04:00" in timer_paused
        assert "Countdown Paused" in timer_paused

        timer_done = render_timer_html(0, is_paused=False)
        assert "00:00" in timer_done
        assert "Session Complete" in timer_done
        print("   -> Timer renders all states correctly.")

        # 4. Blind Recall Submission & Reveal
        print("4. Testing Blind Recall & Reveal...")
        user_recall = "Noticed three distinct ripples on the leaves and a sparrow landing 10 feet away."
        user_reflection = "I hadn't realized how constant the background wind was."

        reveal_html = render_reveal_html(mission, user_recall, user_reflection)
        import html
        assert html.escape(user_recall) in reveal_html
        assert html.escape(user_reflection) in reveal_html
        assert html.escape(mission["title"]) in reveal_html
        assert html.escape(mission["memory_question"]) in reveal_html
        print("   -> Blind recall and reveal comparison verified.")

        # 5. Save to Field Journal
        print("5. Testing Journal Save...")
        saved_entry = journal.save_field_note(
            mission=mission,
            recall_text=user_recall,
            reflection_text=user_reflection,
            environment="Safe outdoor space",
            duration_minutes=5,
        )
        assert saved_entry is not None
        assert test_journal.exists()
        print(f"   -> Saved entry ID: {saved_entry['id']}")

        # 6. Verify in Journal View
        print("6. Testing Journal View Rendering...")
        journal_html, dropdown = render_journal_view()
        assert mission["title"] in journal_html
        assert user_recall in journal_html
        assert len(dropdown.choices) == 1
        print("   -> Journal successfully lists saved note.")

        # 7. Delete Note from Journal
        print("7. Testing Note Deletion...")
        del_success = journal.delete_field_note(saved_entry["id"])
        assert del_success is True
        empty_journal = journal.load_journal()
        assert len(empty_journal) == 0
        journal_empty_html, _ = render_journal_view()
        assert "Your Field Journal is Empty" in journal_empty_html
        print("   -> Note deleted and journal reflects empty state.")

    print("\n✅ All End-to-End Lifecycle Tests PASSED!")


if __name__ == "__main__":
    test_full_lifecycle()
