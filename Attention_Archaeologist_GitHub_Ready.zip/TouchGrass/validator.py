"""
Validation module for Attention Archaeologist observation challenges.

IMPORTANT DISCLAIMER:
This validator performs heuristic keyword checks, pattern analysis, and structural
sanity checks to reject obviously unsafe or malformed missions. It does NOT and
CANNOT guarantee absolute real-world safety under all environmental conditions.
Always prioritize personal judgment, situational awareness, and local laws.
"""

import re
from typing import Dict, Optional, Tuple

# Patterns that suggest physical contact, gathering, or disturbance
FORBIDDEN_ACTIONS = [
    r"\btouch\b",
    r"\bpet\b",
    r"\bhandle\b",
    r"\bgrab\b",
    r"\bpick\s+up\b",
    r"\bpick\s+(?:a\s+|the\s+|any\s+|some\s+)?(?:flower|leaf|leaves|fruit|plant|mushroom|pebble|stone|stick|item|object)\b",
    r"\bpluck\b",
    r"\bharvest\b",
    r"\btaste\b",
    r"\beat\b",
    r"\bchew\b",
    r"\bdrink\b",
    r"\blick\b",
    r"\bsmell\b",
    r"\bsniff\b",
    r"\binhale\b",
    r"\bcollect\b",
    r"\bpocket\b",
    r"\bgather\b",
    r"\bdisturb\b",
    r"\bshake\b",
    r"\bbreak\b",
    r"\bkick\b",
    r"\bpull\b",
    r"\bfeed\b",
    r"\bcatch\b",
    r"\btrap\b",
]

# Patterns that suggest approaching hazards, strangers, or wildlife
FORBIDDEN_APPROACHES_AND_HAZARDS = [
    r"\bstranger",
    r"\bapproach\s+(?:people|someone|stranger|wildlife|animal|bird|insect|bee|wasp)",
    r"\btalk\s+to\s+(?:people|someone|stranger|passerby)",
    r"\bconfront\b",
    r"\bfollow\s+(?:someone|stranger|person)",
    r"\bclimb\b",
    r"\b(?:climb|jump|scale|hop|cross)\s+(?:over\s+|the\s+)?fence\b",
    r"\b(?:go|climb|step)\s+(?:on|onto)\s+the\s+roof\b",
    r"\bladder\b",
    r"\bledge\b",
    r"\bcliff\b",
    r"\bbalcony\s+edge\b",
    r"\blean\s+over\b",
    r"\bprivate\s+property\b",
    r"\btrespass\b",
    r"\bdeep\s+water\b",
    r"\bswim\b",
    r"\benter\s+the\s+(?:road|traffic|highway|street|water|lake|river)",
    r"\bcross\s+the\s+(?:road|highway|street|tracks)",
    r"\brailway\b",
    r"\btrain\s+track",
    r"\belectric\b",
    r"\bpower\s+line\b",
    r"\bhazard",
    r"\bhike\s+into\b",
    r"\brunning\s+across\b",
]

# Patterns that indicate predictive or future-dependent memory questions
FUTURE_DEPENDENT_PATTERNS = [
    r"\bwill\s+(?:happen|appear|come|rain|arrive|change|be)\b",
    r"\bpredict\b",
    r"\btomorrow\b",
    r"\blater\s+today\b",
    r"\bnext\s+(?:hour|day|week|time)\b",
    r"\bin\s+the\s+future\b",
    r"\bwhat\s+is\s+going\s+to\s+happen\b",
    r"\bwhat\s+will\b",
    r"\bwho\s+will\b",
]

# Patterns requiring digital tools, cameras, or specialized gear
FORBIDDEN_EQUIPMENT = [
    r"\bcamera\b",
    r"\bphotograph",
    r"\btake\s+a\s+(?:photo|picture|video|snapshot)",
    r"\brecord\s+(?:audio|video|sound)",
    r"\bmicrophone\b",
    r"\bgps\b",
    r"\bcompass\b",
    r"\bmagnifying\s+glass\b",
    r"\bbinoculars\b",
    r"\bdownload\b",
    r"\bapp\b",
    r"\bphone\s+screen\b",
]

# Length limits for parsed mission components
LIMITS = {
    "title_min": 3,
    "title_max": 90,
    "task_min": 15,
    "task_max": 450,
    "question_min": 10,
    "question_max": 250,
    "total_max": 900,
}


def validate_mission(mission: Dict[str, str]) -> Tuple[bool, str, Optional[Dict[str, str]]]:
    """
    Validates a candidate mission dictionary.
    
    Expected keys:
      - title: str
      - task: str
      - memory_question: str
      - duration: str or int
      
    Returns:
      (is_valid: bool, reason: str, cleaned_mission: Optional[dict])
    """
    if not isinstance(mission, dict):
        return False, "Candidate mission must be a dictionary.", None

    title = str(mission.get("title", "")).strip()
    task = str(mission.get("task", "")).strip()
    memory_question = str(mission.get("memory_question", "")).strip()
    duration = str(mission.get("duration", "")).strip()

    # 1. Missing field checks
    if not title:
        return False, "Missing mission title.", None
    if not task:
        return False, "Missing observation task.", None
    if not memory_question:
        return False, "Missing memory question.", None
    if not duration:
        return False, "Missing duration indicator.", None

    # 2. Length sanity checks
    if len(title) < LIMITS["title_min"] or len(title) > LIMITS["title_max"]:
        return False, f"Title length ({len(title)}) out of bounds [{LIMITS['title_min']}-{LIMITS['title_max']}].", None

    if len(task) < LIMITS["task_min"] or len(task) > LIMITS["task_max"]:
        return False, f"Task length ({len(task)}) out of bounds [{LIMITS['task_min']}-{LIMITS['task_max']}].", None

    if len(memory_question) < LIMITS["question_min"] or len(memory_question) > LIMITS["question_max"]:
        return False, f"Memory question length ({len(memory_question)}) out of bounds [{LIMITS['question_min']}-{LIMITS['question_max']}].", None

    total_len = len(title) + len(task) + len(memory_question)
    if total_len > LIMITS["total_max"]:
        return False, f"Total mission text too verbose ({total_len} chars).", None

    full_text = f"{title}\n{task}\n{memory_question}".lower()

    # 3. Check for physical contact / handling forbidden actions
    for pattern in FORBIDDEN_ACTIONS:
        if re.search(pattern, full_text, re.IGNORECASE):
            return False, f"Rejected due to contact/collection instruction matching '{pattern}'.", None

    # 4. Check for hazardous movements / approaching strangers or dangerous areas
    for pattern in FORBIDDEN_APPROACHES_AND_HAZARDS:
        if re.search(pattern, full_text, re.IGNORECASE):
            return False, f"Rejected due to unsafe location or interaction matching '{pattern}'.", None

    # 5. Check for future-dependent / predictive memory questions
    for pattern in FUTURE_DEPENDENT_PATTERNS:
        if re.search(pattern, memory_question, re.IGNORECASE):
            return False, f"Rejected memory question asking for future prediction matching '{pattern}'.", None

    # 6. Check for equipment/camera/recording requirements
    for pattern in FORBIDDEN_EQUIPMENT:
        if re.search(pattern, full_text, re.IGNORECASE):
            return False, f"Rejected requirement for equipment or recording matching '{pattern}'.", None

    # Cleaned and standardized mission
    cleaned_mission = {
        "title": title,
        "task": task,
        "memory_question": memory_question,
        "duration": duration,
    }

    return True, "Mission passed safety and structural checks.", cleaned_mission
