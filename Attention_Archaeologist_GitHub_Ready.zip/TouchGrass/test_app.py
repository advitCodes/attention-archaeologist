"""
Comprehensive test suite for Attention Archaeologist.

Validates:
1. Validator & Parser logic (valid, missing fields, unsafe actions, future questions, equipment, length)
2. Fallback catalog integrity (structure, safety, variety across environments and durations)
3. Local Field Journal operations (saving, loading, deleting, clearing, corrupted file resilience)
4. Generator response parser
5. Ollama probe / connection status
"""

import json
import os
import tempfile
import unittest
from pathlib import Path

import config
from fallbacks import CURATED_FALLBACK_MISSIONS, get_fallback_mission
from generator import check_ollama_available, parse_model_response
import journal
from validator import validate_mission


class TestMissionValidator(unittest.TestCase):
    def test_valid_mission(self):
        valid_input = {
            "title": "The Shadow Boundary",
            "task": "Find the sharpest edge of a shadow cast on the ground and watch it without moving.",
            "memory_question": "What texture did the shadow edge fall across?",
            "duration": "5 minutes",
        }
        is_valid, reason, cleaned = validate_mission(valid_input)
        self.assertTrue(is_valid, f"Expected valid, got reason: {reason}")
        self.assertIsNotNone(cleaned)
        self.assertEqual(cleaned["title"], "The Shadow Boundary")

    def test_missing_fields(self):
        cases = [
            {"task": "Observe a leaf", "memory_question": "What color?", "duration": "5m"},  # missing title
            {"title": "Test", "memory_question": "What color?", "duration": "5m"},            # missing task
            {"title": "Test", "task": "Observe a leaf", "duration": "5m"},                     # missing question
            {"title": "Test", "task": "Observe a leaf", "memory_question": "What color?"},     # missing duration
        ]
        for c in cases:
            is_valid, reason, _ = validate_mission(c)
            self.assertFalse(is_valid, f"Expected invalid for missing field case {c}, got {reason}")

    def test_unsafe_contact_and_sampling(self):
        unsafe_tasks = [
            "Touch the wet bark of the tree to feel its mossy texture.",
            "Pick a flower and tear its petals apart.",
            "Taste the rain puddle droplets on the leaf.",
            "Smell the flowers and inhale their fragrance closely.",
            "Collect five pebbles and put them in your pocket.",
            "Feed the pigeons some crumbs from your hand.",
            "Disturb the soil with your fingers to find worms.",
        ]
        for task in unsafe_tasks:
            cand = {
                "title": "Tactile Test",
                "task": task,
                "memory_question": "How did it feel?",
                "duration": "5 minutes",
            }
            is_valid, reason, _ = validate_mission(cand)
            self.assertFalse(is_valid, f"Should reject unsafe contact '{task}', but passed!")

    def test_unsafe_locations_and_interactions(self):
        unsafe_tasks = [
            "Approach a stranger and ask what they are doing.",
            "Climb the balcony ledge to get a better view.",
            "Enter private property behind the fence.",
            "Walk into the road and cross the highway to see cars.",
            "Approach the swarm of bees near the bush.",
            "Lean over the cliff edge to look down.",
        ]
        for task in unsafe_tasks:
            cand = {
                "title": "Hazardous Exploration",
                "task": task,
                "memory_question": "What did you notice?",
                "duration": "5 minutes",
            }
            is_valid, reason, _ = validate_mission(cand)
            self.assertFalse(is_valid, f"Should reject hazard '{task}', but passed!")

    def test_future_dependent_questions(self):
        future_questions = [
            "What will happen when the sun sets later today?",
            "Predict how many birds will fly by in the next hour.",
            "Will it rain tomorrow?",
            "What is going to happen next to the moving car?",
        ]
        for q in future_questions:
            cand = {
                "title": "Future Forecaster",
                "task": "Observe the distant sky stationary for five minutes.",
                "memory_question": q,
                "duration": "5 minutes",
            }
            is_valid, reason, _ = validate_mission(cand)
            self.assertFalse(is_valid, f"Should reject future question '{q}', but passed!")

    def test_forbidden_equipment(self):
        equipment_tasks = [
            "Take a photo of the tree with your camera.",
            "Record audio of the birds using your phone microphone.",
            "Open your compass app to measure bearing.",
        ]
        for task in equipment_tasks:
            cand = {
                "title": "Digital Capture",
                "task": task,
                "memory_question": "Did the photo look clear?",
                "duration": "5 minutes",
            }
            is_valid, reason, _ = validate_mission(cand)
            self.assertFalse(is_valid, f"Should reject equipment task '{task}', but passed!")

    def test_excessive_length(self):
        huge_task = "Look closely. " * 60
        cand = {
            "title": "Normal Title",
            "task": huge_task,
            "memory_question": "What did you see?",
            "duration": "5 minutes",
        }
        is_valid, reason, _ = validate_mission(cand)
        self.assertFalse(is_valid, "Should reject excessively long mission text.")


class TestFallbackCatalog(unittest.TestCase):
    def test_curated_missions_validity(self):
        self.assertGreaterEqual(len(CURATED_FALLBACK_MISSIONS), 5)
        for m in CURATED_FALLBACK_MISSIONS:
            is_valid, reason, _ = validate_mission(m)
            self.assertTrue(is_valid, f"Curated mission '{m.get('title')}' failed validator: {reason}")

    def test_fallback_selection_variety(self):
        for env in ["Safe outdoor space", "Through a window", "Either"]:
            for dur in [3, 5, 7]:
                m = get_fallback_mission(environment=env, duration_minutes=dur)
                self.assertIn("title", m)
                self.assertIn("task", m)
                self.assertIn("memory_question", m)
                self.assertEqual(m["duration"], f"{dur} minutes")


class TestGeneratorParser(unittest.TestCase):
    def test_parse_clean_output(self):
        sample = """
Mission: The Whispering Leaves
Observe: Watch the gentle sway of the oak tree branches against the cloudless sky.
Remember: Which branch dipped lowest during your observation?
Time: 5 minutes
"""
        parsed = parse_model_response(sample, duration_minutes=5)
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["title"], "The Whispering Leaves")
        self.assertIn("oak tree", parsed["task"])
        self.assertIn("Which branch", parsed["memory_question"])

    def test_parse_with_asterisks_and_spacing(self):
        sample = """
Here is your challenge:
**Mission**: Urban Geometry
**Observe**: Locate three distinct right angles formed by buildings or windows.
**Remember**: How many angles were in direct sunlight?
**Time**: 3 minutes
Hope you enjoy it!
"""
        parsed = parse_model_response(sample, duration_minutes=3)
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["title"], "Urban Geometry")


class TestFieldJournal(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.TemporaryDirectory()
        self.test_journal_file = Path(self.test_dir.name) / "test_journal.json"
        self._orig_path = config.JOURNAL_FILE_PATH
        config.JOURNAL_FILE_PATH = self.test_journal_file

    def tearDown(self):
        config.JOURNAL_FILE_PATH = self._orig_path
        self.test_dir.cleanup()

    def test_missing_file_handled_gracefully(self):
        # File doesn't exist yet
        entries = journal.load_journal()
        self.assertEqual(entries, [])

    def test_save_and_load_entry(self):
        mission = {
            "title": "Sun Reflection",
            "task": "Observe glints of sun on the window.",
            "memory_question": "How many glints?",
            "duration": "5 minutes",
        }
        saved = journal.save_field_note(
            mission=mission,
            recall_text="Saw 4 bright sparks of light reflecting off car windshield.",
            reflection_text="I noticed cars pass less frequently than I thought.",
            environment="Through a window",
            duration_minutes=5,
        )
        self.assertIsNotNone(saved)
        self.assertEqual(saved["mission_title"], "Sun Reflection")
        self.assertTrue(self.test_journal_file.exists())

        loaded = journal.load_journal()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["id"], saved["id"])
        self.assertEqual(loaded[0]["recall"], "Saw 4 bright sparks of light reflecting off car windshield.")

    def test_delete_entry(self):
        m = {"title": "A", "task": "Task A", "memory_question": "Q A", "duration": "3m"}
        e1 = journal.save_field_note(m, "Recall 1")
        e2 = journal.save_field_note(m, "Recall 2")

        self.assertEqual(len(journal.load_journal()), 2)
        success = journal.delete_field_note(e1["id"])
        self.assertTrue(success)

        remaining = journal.load_journal()
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0]["id"], e2["id"])

    def test_clear_all_notes(self):
        m = {"title": "A", "task": "Task A", "memory_question": "Q A", "duration": "3m"}
        journal.save_field_note(m, "Recall 1")
        journal.save_field_note(m, "Recall 2")

        self.assertEqual(len(journal.load_journal()), 2)
        journal.clear_all_notes()
        self.assertEqual(journal.load_journal(), [])

    def test_corrupted_journal_handled_gracefully(self):
        # Write corrupted JSON
        self.test_journal_file.write_text("{invalid json", encoding="utf-8")
        entries = journal.load_journal()
        self.assertEqual(entries, [], "Corrupted JSON should return [] without raising an exception.")


if __name__ == "__main__":
    unittest.main()
