"""Alias launcher for TouchGrass / Attention Archaeologist."""
from main import main

if __name__ == "__main__":
    main()
