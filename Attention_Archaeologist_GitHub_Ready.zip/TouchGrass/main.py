"""
Attention Archaeologist — Application Entrypoint

Launches the complete Attention Archaeologist application.
Also supports a CLI dry-run mode for quick terminal testing.
"""

import argparse
import sys
from app import APP_THEME, CUSTOM_CSS, build_app
from generator import check_ollama_available, generate_mission


def run_cli_test():
    """Runs a quick CLI test preserving the original terminal workflow."""
    print("=" * 60)
    print("Attention Archaeologist — CLI Field Mission Generator")
    print("=" * 60)
    print("Probing local Ollama instance...")
    is_online = check_ollama_available()
    print(f"Ollama status: {'CONNECTED' if is_online else 'OFFLINE (Curated fallback active)'}")
    
    print("\nGenerating sample mission (Environment: Safe outdoor space, Duration: 5m)...")
    res = generate_mission(environment="Safe outdoor space", duration_minutes=5)
    
    print(f"Source: {res['source'].upper()}")
    print(f"Status: {res['status_message']}")
    print("-" * 60)
    m = res["mission"]
    print(f"Mission:  {m.get('title')}")
    print(f"Duration: {m.get('duration')}")
    print(f"Observe:  {m.get('task')}")
    print(f"Remember: {m.get('memory_question')}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description="Attention Archaeologist")
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Run single observation generation in terminal instead of starting the web UI.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=7860,
        help="Port to bind the Gradio web server to (default: 7860).",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host address to bind to (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--share",
        action="store_true",
        help="Create a public Gradio share link.",
    )

    args = parser.parse_args()

    if args.cli:
        run_cli_test()
        sys.exit(0)

    print("\n" + "=" * 60)
    print("🧭 Starting Attention Archaeologist...")
    print(f"📍 Local Interface: http://{args.host}:{args.port}")
    print("🌿 Press Ctrl+C in terminal to stop the server.")
    print("=" * 60 + "\n")

    app = build_app()
    app.launch(
        server_name=args.host,
        server_port=args.port,
        share=args.share,
        show_error=True,
        theme=APP_THEME,
        css=CUSTOM_CSS,
    )


if __name__ == "__main__":
    main()