"""
Local Field Journal persistence module for Attention Archaeologist.

Handles saving, loading, deleting, and clearing field notes in a local JSON file.
Protects against missing, corrupt, or malformed files using safe parsing and atomic writes.
"""

import json
import os
import tempfile
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import config


def _get_journal_path() -> Path:
    return Path(config.JOURNAL_FILE_PATH)


def load_journal() -> List[Dict[str, Any]]:
    """
    Loads all saved journal entries from disk.
    Returns an empty list if the file doesn't exist, is empty, or is corrupted.
    """
    path = _get_journal_path()
    if not path.exists():
        return []

    try:
        content = path.read_text(encoding="utf-8").strip()
        if not content:
            return []
        data = json.loads(content)
        if isinstance(data, list):
            # Sort newest first based on timestamp or ISO string
            def sort_key(entry):
                return entry.get("timestamp_iso", "") or entry.get("timestamp", "")
            return sorted(data, key=sort_key, reverse=True)
        return []
    except (json.JSONDecodeError, OSError) as e:
        # File is corrupt or unreadable; log warning and return empty without crashing
        print(f"[Warning] Journal file at {path} could not be parsed: {e}")
        return []


def _save_journal_list(entries: List[Dict[str, Any]]) -> bool:
    """Atomically saves list of journal entries to JSON."""
    path = _get_journal_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Write to temporary file first in the same directory for atomic replace
        with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False, encoding="utf-8") as tf:
            json.dump(entries, tf, indent=2, ensure_ascii=False)
            temp_name = tf.name
        os.replace(temp_name, path)
        return True
    except Exception as e:
        print(f"[Error] Failed to write journal entries: {e}")
        if 'temp_name' in locals() and os.path.exists(temp_name):
            try:
                os.remove(temp_name)
            except OSError:
                pass
        return False


def save_field_note(
    mission: Dict[str, str],
    recall_text: str,
    reflection_text: str = "",
    environment: str = "Safe outdoor space",
    duration_minutes: int = 5,
) -> Optional[Dict[str, Any]]:
    """
    Saves a new observation recall and reflection note to the local journal.
    """
    now = datetime.now()
    readable_timestamp = now.strftime("%B %d, %Y at %I:%M %p")
    iso_timestamp = now.isoformat()

    entry = {
        "id": str(uuid.uuid4()),
        "timestamp": readable_timestamp,
        "timestamp_iso": iso_timestamp,
        "mission_title": mission.get("title", "Untitled Mission"),
        "duration": mission.get("duration", f"{duration_minutes} minutes"),
        "duration_minutes": duration_minutes,
        "environment": environment,
        "recall": recall_text.strip(),
        "reflection": reflection_text.strip() if reflection_text else "",
        "original_mission": {
            "title": mission.get("title", ""),
            "task": mission.get("task", ""),
            "memory_question": mission.get("memory_question", ""),
            "duration": mission.get("duration", ""),
        },
    }

    entries = load_journal()
    entries.insert(0, entry)
    success = _save_journal_list(entries)
    if success:
        return entry
    return None


def delete_field_note(entry_id: str) -> bool:
    """Deletes a specific note by its UUID."""
    if not entry_id:
        return False
    entries = load_journal()
    original_count = len(entries)
    filtered = [e for e in entries if e.get("id") != entry_id]
    if len(filtered) != original_count:
        return _save_journal_list(filtered)
    return False


def clear_all_notes() -> bool:
    """Wipes the journal after user confirmation."""
    return _save_journal_list([])
