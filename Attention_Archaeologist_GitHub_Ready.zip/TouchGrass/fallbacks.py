"""
Curated fallback missions for Attention Archaeologist.

Each mission is designed as a focused, stationary micro-experiment that requires
zero equipment, works in almost any setting (including looking out through a window),
and asks an immediate recall question.
"""

import random
from typing import Dict, List, Optional

CURATED_FALLBACK_MISSIONS: List[Dict[str, str]] = [
    {
        "id": "shadow_boundary",
        "title": "The Shadow Boundary",
        "task": "Find the sharpest edge of a shadow cast on any flat surface (floor, wall, sill, or ground). From a stationary position, watch that single line without moving. Notice whether the edge appears crisp or fuzzy, and whether it shifts across any surface texture.",
        "memory_question": "Which surface texture did the shadow edge fall across, and was the transition razor-sharp or soft?",
        "environment": "Either",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "tri_color_strata",
        "title": "Tri-Color Strata",
        "task": "Without moving from your stationary spot, locate three distinctly different shades of the same broad color family (e.g., three different greens, browns, or grays). Trace a mental triangle connecting their positions in your field of view.",
        "memory_question": "What were the three specific objects carrying those shades, and which one was closest to your eye?",
        "environment": "Either",
        "duration": "3 minutes",
        "default_duration_num": 3,
    },
    {
        "id": "acoustic_layering",
        "task": "Stay in one spot with a soft gaze. Divide your auditory field into two distinct zones: sounds happening within arm's reach or inside your immediate room, and sounds originating far in the distance. Note which sound repeats most frequently.",
        "title": "Acoustic Layering",
        "memory_question": "What was the most distant distinct sound you detected, and did it happen continuously or in pulses?",
        "environment": "Either",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "wind_oscillation",
        "title": "Wind-Tethered Oscillation",
        "task": "Select one specific flexible object visible from your position—a hanging leaf, a blade of grass, a cable, or a cloth banner. Watch only this object. Observe its resting posture versus how it reacts when airflow nudges it.",
        "memory_question": "Did the object oscillate in an oval, a straight sway, or irregular fluttering bursts?",
        "environment": "Safe outdoor space",
        "duration": "3 minutes",
        "default_duration_num": 3,
    },
    {
        "id": "window_reflections",
        "title": "Dual-Plane Window Study",
        "task": "Stand or sit stationary in front of a window pane. Intentionally switch your focus back and forth: first focus on the surface of the glass (reflections of your interior room, smudges, raindrops), then shift your depth-of-field to the outdoors beyond.",
        "memory_question": "What was the clearest reflection visible on the glass surface while you looked through it?",
        "environment": "Through a window",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "perimeter_of_stillness",
        "title": "The Perimeter of Stillness",
        "task": "Scan your entire field of view and locate the single element that appears the most completely motionless. Keep your eyes anchored on it while letting your peripheral vision detect all surrounding movement.",
        "memory_question": "What object was your anchor of stillness, and what was the nearest moving thing in your peripheral view?",
        "environment": "Either",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "structural_branching",
        "title": "Structural Hierarchy",
        "task": "Find a branching structure visible from where you are—such as tree limbs, utility lines, cracks in pavement, or window muntins. Trace the path from the thickest 'trunk' line all the way to its finest branching endpoint.",
        "memory_question": "How many branching divisions or forks did you count along the path you traced?",
        "environment": "Either",
        "duration": "7 minutes",
        "default_duration_num": 7,
    },
    {
        "id": "horizon_intersect",
        "title": "The Horizontal Cut",
        "task": "Mentally establish one steady horizontal line across your view (a windowsill, rooftop line, fence top, or horizon). Observe everything that crosses or punctures this line vertically.",
        "memory_question": "How many vertical structures or natural shapes pierced your imaginary horizontal line?",
        "environment": "Either",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "light_glints",
        "title": "Incidental Glints",
        "task": "Keep your head stationary and scan for tiny points of specular light: sunlight glinting off a wet leaf, a car mirror, metal railing, or polished stone. Watch one glint to see if ambient lighting dims or brightens it.",
        "memory_question": "On what material was the brightest glint located, and did its intensity fluctuate?",
        "environment": "Safe outdoor space",
        "duration": "3 minutes",
        "default_duration_num": 3,
    },
    {
        "id": "negative_space",
        "title": "Negative Space Silhouette",
        "task": "Look at the open space or sky framed between two solid structures (such as buildings, tree branches, or window dividers). Focus purely on the shape of the empty gap rather than the physical objects themselves.",
        "memory_question": "What geometric or organic contour best described the empty gap you framed?",
        "environment": "Through a window",
        "duration": "5 minutes",
        "default_duration_num": 5,
    },
    {
        "id": "texture_gradient",
        "title": "The Texture Gradient",
        "task": "Compare the visual texture of an object close to you (within 1 to 2 meters) against an object at the furthest edge of your view. Note which fine details are immediately lost over distance.",
        "memory_question": "What fine detail was prominent on the near object that completely vanished on the distant one?",
        "environment": "Either",
        "duration": "7 minutes",
        "default_duration_num": 7,
    },
    {
        "id": "velocity_contrast",
        "title": "Velocity Contrast",
        "task": "Identify two distinct moving things in your visual field—for example, clouds or swaying tree crowns versus moving pedestrians or birds. Track both and compare their apparent speeds relative to stationary landmarks.",
        "memory_question": "Which of the two moving elements changed directions most frequently?",
        "environment": "Either",
        "duration": "7 minutes",
        "default_duration_num": 7,
    },
]


def get_fallback_mission(environment: str = "Either", duration_minutes: int = 5) -> Dict[str, str]:
    """
    Selects a curated fallback mission suited for the environment and duration.
    Always returns a valid, safe mission dictionary.
    """
    env_clean = (environment or "").strip().lower()
    
    # Filter candidates
    candidates = []
    for m in CURATED_FALLBACK_MISSIONS:
        m_env = m["environment"].lower()
        # Matches environment if either matches or candidate is flexible ('either')
        if env_clean in ["either", ""] or m_env == "either" or env_clean in m_env:
            candidates.append(m)

    if not candidates:
        candidates = CURATED_FALLBACK_MISSIONS

    # Pick candidate
    chosen = random.choice(candidates).copy()
    
    # Format duration appropriately
    duration_str = f"{duration_minutes} minutes"
    
    return {
        "title": chosen["title"],
        "task": chosen["task"],
        "memory_question": chosen["memory_question"],
        "duration": duration_str,
    }
